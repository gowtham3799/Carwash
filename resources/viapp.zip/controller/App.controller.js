sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("viapp.controller.App",{})});
//# sourceMappingURL=App.controller.js.map